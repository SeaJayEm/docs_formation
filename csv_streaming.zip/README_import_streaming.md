# Données propres - Projet Streaming

Ce dossier contient deux formats équivalents pour alimenter la base `streaming` :

- des fichiers CSV, un par table ;
- un script SQL `INSERT`.

Les deux méthodes insèrent les mêmes données.

## Ordre conseillé d'import des CSV

1. `film.csv`
2. `realisateur.csv`
3. `acteur.csv`
4. `utilisateur.csv`
5. `film_realisateur.csv`
6. `film_acteur.csv`
7. `visionnage.csv`

Les tables d'association et `visionnage` doivent être importées après les tables qu'elles référencent.
