CREATE TABLE IF NOT EXISTS "categorie" (
	"categorie_id" INTEGER NOT NULL UNIQUE,
	"categorie_nom" TEXT NOT NULL UNIQUE,
	PRIMARY KEY("categorie_id")
);

CREATE TABLE IF NOT EXISTS "fournisseur" (
	"fournisseur_id" INTEGER NOT NULL UNIQUE,
	"fournisseur_nom" TEXT NOT NULL UNIQUE,
	"fournisseur_pays" TEXT NOT NULL,
	"fournisseur_contact" TEXT,
	PRIMARY KEY("fournisseur_id")
);

CREATE TABLE IF NOT EXISTS "client" (
	"client_id" TEXT NOT NULL UNIQUE,
	"client_nom" TEXT NOT NULL,
	"client_email" TEXT NOT NULL UNIQUE,
	"client_type" TEXT NOT NULL,
	"client_ville" TEXT NOT NULL,
	"magasin_region" TEXT,
	"magasin_surface_m2" INTEGER,
	PRIMARY KEY("client_id")
);

CREATE TABLE IF NOT EXISTS "sousCategorie" (
	"sous_categorie_id" INTEGER NOT NULL UNIQUE,
	"sous_categorie_nom" TEXT NOT NULL UNIQUE,
	"categorie_id" INTEGER NOT NULL,
	PRIMARY KEY("sous_categorie_id"),
	FOREIGN KEY ("categorie_id") REFERENCES "categorie"("categorie_id")
	ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS "jeu" (
	"jeu_id" TEXT NOT NULL UNIQUE,
	"jeu_nom" TEXT NOT NULL,
	"age_minimum" INTEGER NOT NULL,
	"prix_unitaire_catalogue" REAL NOT NULL,
	"fournisseur_id" INTEGER NOT NULL,
	"sous_categorie_id" INTEGER NOT NULL,
	PRIMARY KEY("jeu_id"),
	FOREIGN KEY ("fournisseur_id") REFERENCES "fournisseur"("fournisseur_id")
	ON UPDATE NO ACTION ON DELETE NO ACTION,
	FOREIGN KEY ("sous_categorie_id") REFERENCES "sousCategorie"("sous_categorie_id")
	ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS "commande" (
	"commande_id" TEXT NOT NULL UNIQUE,
	"date_commande" DATE NOT NULL,
	"canal_commande" TEXT NOT NULL,
	"mode_livraison" TEXT NOT NULL,
	"client_id" TEXT NOT NULL,
	PRIMARY KEY("commande_id"),
	FOREIGN KEY ("client_id") REFERENCES "client"("client_id")
	ON UPDATE NO ACTION ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS "ligneCommande" (
	"ligne_commande_id" INTEGER NOT NULL UNIQUE,
	"commande_id" TEXT NOT NULL,
	"jeu_id" TEXT NOT NULL,
	"quantite" INTEGER NOT NULL,
	"remise_pourcentage" REAL,
	"prix_unitaire_apres_remise" REAL NOT NULL,
	PRIMARY KEY("ligne_commande_id"),
	FOREIGN KEY ("commande_id") REFERENCES "commande"("commande_id")
	ON UPDATE NO ACTION ON DELETE NO ACTION,
	FOREIGN KEY ("jeu_id") REFERENCES "jeu"("jeu_id")
	ON UPDATE NO ACTION ON DELETE NO ACTION
);
